package com.cmis.domain;

public class MemberVO {
	private String member_name;
	private String user_id;
	private String member_pw;
	private int member_sex;
	private int member_age;
	private String member_phone;
	private String member_address;
	private String member_sns;
	private int member_lv;
	
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getMember_pw() {
		return member_pw;
	}
	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}
	public int getMember_sex() {
		return member_sex;
	}
	public void setMember_sex(int member_sex) {
		this.member_sex = member_sex;
	}
	public int getMember_age() {
		return member_age;
	}
	public void setMember_age(int member_age) {
		this.member_age = member_age;
	}
	public String getMember_phone() {
		return member_phone;
	}
	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}
	public String getMember_address() {
		return member_address;
	}
	public void setMember_address(String member_address) {
		this.member_address = member_address;
	}
	public String getMember_sns() {
		return member_sns;
	}
	public void setMember_sns(String member_sns) {
		this.member_sns = member_sns;
	}
	public int getMember_lv() {
		return member_lv;
	}
	public void setMember_lv(int member_lv) {
		this.member_lv = member_lv;
	}

}
