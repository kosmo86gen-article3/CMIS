package com.cmis.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MapController {
	
	// 로그인 작동
	@RequestMapping("map.do")
	public void searchShopList(HttpSession session) {
		
		
		
	}

}
